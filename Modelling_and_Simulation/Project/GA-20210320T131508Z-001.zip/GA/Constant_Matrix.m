%Constant Matrix

m = 10; %Mass of Washing Machine
mu = 2; %Unbalanced Mass
r = 0.25; %Radius
N = 30*pi;

constant_mat = [m; mu; r; N];