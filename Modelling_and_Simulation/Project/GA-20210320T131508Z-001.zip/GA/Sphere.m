
function  [fitness_value] = Sphere(design_matrix)
  
   optim_matrix = simRun(design_matrix);
   [row, col] = size(optim_matrix);
   
   for i =1:col
       
       [xtr_max, xst_max,ztr_max, zst_max, xtr_min, xst_min, ztr_min, zst_min ] = optim_matrix(:,i);

       fitness_value(i) = 1/(xtr_max+xst_max+ztr_max+zst_max-xtr_min-xst_min-ztr_min-zst_min);
   end
   
end